import pyautogui
import cv2
import numpy as np
import pytesseract
import re
import time
import subprocess
import os
import ctypes
from datetime import datetime
import json
import base64
import requests
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
import cv2, pytesseract, numpy as np, os, base64
from datetime import datetime
from get_epay_sign import refund_order
from clear_tab import get_balance_func, get_alert_func
PID = 1001 
KEY = ""#商户秘钥

pyautogui.FAILSAFE = False


last_sync_time = "还未进行同步过！"
last_sync_screenshot = "" #B64 IMG
last_sync_balance = "还未进行同步过！"

proxies = {
    "http": "http://127.0.0.1:7890",
    "https": "http://127.0.0.1:7890",
}

def compress_base64_image(
    base64_str: str,
    quality: int = 70,  # 质量压缩（1-100，越低越小，JPG 有效）
    max_width: int = None,  # 最大宽度（超过则等比缩放，None 不限制）
    max_height: int = None,  # 最大高度（超过则等比缩放，None 不限制）
    img_format: str = "JPEG"  # 输出格式（JPEG/PNG，透明图用 PNG）
) -> str:
    """
    压缩 Base64 编码的图片，返回压缩后的 Base64 字符串
    
    参数说明：
    - base64_str: 原始 Base64 图片字符串（含/不含前缀 "data:image/xxx;base64," 均可）
    - quality: 质量压缩参数（仅 JPEG 有效，PNG 建议通过缩放减小体积）
    - max_width/max_height: 缩放限制（等比缩放，不超过该尺寸）
    - img_format: 输出格式（JPEG 体积更小，PNG 支持透明）
    """
    # 1. 移除 Base64 前缀（如果有）
    if base64_str.startswith("data:image"):
        base64_str = base64_str.split(";base64,")[-1]
    
    # 2. Base64 解码为字节流
    img_bytes = base64.b64decode(base64_str)
    img = Image.open(BytesIO(img_bytes))
    
    # 3. 分辨率缩放（等比缩小，避免拉伸）
    if max_width or max_height:
        width, height = img.size
        # 计算缩放比例（取宽高比例的最小值，确保不超过限制）
        scale = 1.0
        if max_width and width > max_width:
            scale = min(scale, max_width / width)
        if max_height and height > max_height:
            scale = min(scale, max_height / height)
        
        if scale < 1.0:  # 只有需要缩小时才处理
            new_width = int(width * scale)
            new_height = int(height * scale)
            # 缩放（ANTIALIAS 抗锯齿，保证画质）
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
    
    # 4. 质量压缩 + 编码为 Base64
    output = BytesIO()
    # PNG 不支持 quality 参数，通过优化参数减小体积
    if img_format == "PNG":
        img.save(
            output,
            format=img_format,
            optimize=True,  # 开启 PNG 优化
            compress_level=6  # PNG 压缩级别（0-9，越高越小但越慢）
        )
    else:  # JPEG
        # 处理透明通道（JPEG 不支持透明，转为白色背景）
        if img.mode in ("RGBA", "P"):
            background = Image.new("RGB", img.size, (255, 255, 255))
            background.paste(img, mask=img.split()[3] if img.mode == "RGBA" else None)
            img = background
        img.save(output, format=img_format, quality=quality, optimize=True)
    
    # 5. 字节流重新编码为 Base64
    compressed_base64 = base64.b64encode(output.getvalue()).decode("utf-8")
    return compressed_base64

# # ------------------- 测试示例 -------------------
# if __name__ == "__main__":
#     # 假设这是你的原始 Base64 图片（实际使用时替换为你的字符串）
#     original_base64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAMAAABHPGVmAAAAUVBMVEWFhYWDg4N3d3dtbW17e3t1dXWBgYGHh4d5eXlzc3OLi4ubm5uVlZWPj4+NjY19fX2JiYl/f39ra2uRkZGZmZlpaWmXl5dvb29xcXGTk5NnZ2c4zIwLAAAAG3RSTlMAf4CXRf+7v8S2LgAGQ4VGh1JU6LjgCBgUBF2QdFJsKCAkR5ZUWEg4dLjAtJ5Q4QigKAgQFAD9e393h4uGAAAAAElFTkSuQmCC"
    
#     # 压缩参数：质量70，最大宽度800px，输出JPEG格式
#     compressed_base64 = compress_base64_image(
#         base64_str=original_base64,
#         quality=70,
#         max_width=800,
#         img_format="JPEG"
#     )
    
#     # 输出结果（可选：添加前缀，方便前端直接使用）
#     final_base64 = f"data:image/jpeg;base64,{compressed_base64}"
#     print("压缩后的 Base64 长度:", len(compressed_base64))
#     print("最终 Base64（前100字符）:", final_base64[:100])
def process_screenshot(filename, sensitive_keywords=None, watermark="CAKE"):
    """
    对截图处理：
    1. OCR识别
    2. 对含有 sensitive_keywords 的区域打码
    3. 左下角加微软雅黑水印
    """
    sensitive_keywords = ["CAKE", "CT", "CTCAKE", "ct", "ctcake", "cake"]
    img = cv2.imread(filename)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    data = pytesseract.image_to_data(gray, output_type=pytesseract.Output.DICT)

    # 打码敏感文字区域
    for i, text in enumerate(data["text"]):
        if text.strip() and any(kw.lower() in text.lower() for kw in sensitive_keywords):
            x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
            roi = img[y:y+h, x:x+w]
            roi = cv2.GaussianBlur(roi, (15, 15), 30)
            img[y:y+h, x:x+w] = roi

    # 临时保存
    time_name = datetime.now().strftime("%Y%m%d%H%M%S")
    tmp = "_tmp_"+time_name+".png"
    cv2.imwrite(tmp, img)

    # Pillow 加水印
    im = Image.open(tmp)
    draw = ImageDraw.Draw(im)
    yahei_path = "C:/Windows/Fonts/msyh.ttc"
    font = ImageFont.truetype(yahei_path, 26)
    bbox = draw.textbbox((0,0), watermark, font=font)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    x, y = 15, im.height - text_h - 15
    draw.rectangle((x-8, y-5, x+text_w+8, y+text_h+5), fill=(0,0,0,160))
    draw.text((x, y), watermark, font=font, fill=(255,255,255))

    final_filename = "final_" + time_name + ".png"

    im.save(final_filename)
    os.remove(tmp)
 
    # 返回 base64
    with open(final_filename, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    compressed_base64 = compress_base64_image(
        base64_str=b64,
        quality=70,
        max_width=1000,
        img_format="JPEG"
    )
    final_base64 = compressed_base64
    return final_base64, final_filename

chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
user_data = r"C:\Users\Administrator\AppData\Local\Google\Chrome\User Data"
# ================== 工具函数 ==================
TESSERACT_CMD = r"C:\Program Files\Tesseract-OCR\tesseract.exe"  # <-- modify if needed
pytesseract.pytesseract.tesseract_cmd = TESSERACT_CMD

SYNC_URL = "https://static.hvhgod.onl/sync.php"
SYNC_TOKEN = "ctcake1337"


def refund(order_id, amount):
    # 发起退款
    #收取手续费1元
    # if float(amount) < 5:
    #     return False, "金额不足5元，无法退款"
    if float(amount) < 1:
        amount = float(amount)
    amount = float(amount) - 1
    
    result = refund_order(
        pid=PID,
        key=KEY,
        out_trade_no=order_id,
        money=amount
    )
    if result['code'] != 0:
        print(f"退款失败: {result['msg']}")
        return False, result['msg']
    else:
        print(f"退款成功: {result['msg']}")
        return True, '手续费￥1。' + result['msg']


def sync_fats_balance():
    balance_result = sync_fats_balance_o()  # 本身就是字典
    

    try:
        resp = requests.post(SYNC_URL, json=balance_result, timeout=None, proxies=proxies)  # 不限制超时
        if resp.status_code == 200:
            print("[SYNC SUCCESS] 数据已同步至 sync.php" + resp.text)
            print(json.dumps(resp.json()))

        else:
            print(f"[SYNC FAIL] 状态码: {resp.status_code}, 内容: {resp.text}")
    except Exception as e:
        print(f"[SYNC ERROR] {e}")

    return balance_result



def bring_window_to_front(title_substr):
    """将包含 title_substr 的窗口置于前台"""
    return
    try:
        import win32gui
        import win32con
        def enumHandler(hwnd, lParam):
            # lParam 参数未使用，但必须保留以匹配 win32gui.EnumWindows 的回调签名
            if win32gui.IsWindowVisible(hwnd):
                if title_substr.lower() in win32gui.GetWindowText(hwnd).lower():
                    try:
                        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                        win32gui.SetForegroundWindow(hwnd)
                    except Exception as e:
                        print(f"[SYNC ERROR] 设置窗口焦点失败: {e}")
                        # 不设置焦点，直接继续执行
        win32gui.EnumWindows(enumHandler, None)
    except ImportError:
        # fallback: 使用 ctypes
        try:
            ctypes.windll.user32.SetForegroundWindow(ctypes.windll.user32.GetForegroundWindow())
        except Exception as e:
            print(f"[SYNC ERROR] 设置窗口焦点失败: {e}")
            # 不设置焦点，直接继续执行

def safe_screenshot(max_retries=10, retry_delay=0.5):
    """安全截图函数，当截图失败时循环重试直到成功"""
    retries = 0
    while retries < max_retries:
        try:
            return pyautogui.screenshot()
        except Exception as e:
            print(f"[SCREENSHOT ERROR] 截图失败，正在重试 ({retries+1}/{max_retries}): {e}")
            retries += 1
            time.sleep(retry_delay)

    # 如果所有重试都失败，抛出异常
    raise Exception(f"[SCREENSHOT ERROR] 截图失败，已重试 {max_retries} 次")

def check_cf():
    """检测并点击 CF 盾"""
    templates = ["checkbox.png", "checkbox_dark.png"]
    threshold = 0.8
    screenshot = safe_screenshot()
    screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
    for path in templates:
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[CF WARN] 模板不存在: {path}")
            continue
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= threshold:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[CF FOUND] 点击成功: {path}, 匹配度: {max_val:.2f}")
            return True
    return False

def check_wallet(timeout=8):
    """检测并点击 wallet，超时返回 False"""
    start = time.time()
    while time.time() - start < timeout:
        screenshot = safe_screenshot()
        screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
        path = "wallet.png"
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[WALLET WARN] 模板不存在: {path}")
            return False
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= 0.8:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[WALLET FOUND] 点击成功, 匹配度: {max_val:.2f}")
            return True
        time.sleep(0.5)
    print("[WALLET TIMEOUT] 未检测到 wallet")
    return False

def check_store(timeout=8):
    """检测并点击 store,失败 False"""
    start = time.time()
    while time.time() - start < timeout:
        screenshot = safe_screenshot()
        screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
        path = "store.png"
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[WALLET WARN] 模板不存在: {path}")
            return False
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= 0.8:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[WALLET FOUND] 点击成功, 匹配度: {max_val:.2f}")
            return True
        time.sleep(0.5)
    print("[WALLET TIMEOUT] 未检测到 wallet")
    return False

def click_pay_method(timeout=8):
    """检测并点击 pay method,失败 False"""
    start = time.time()
    while time.time() - start < timeout:
        screenshot = safe_screenshot()
        screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
        path = "paymethod.png"
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[支付方式 WARN] 模板不存在: {path}")
            return False
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= 0.8:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[支付方式 FOUND] 点击成功, 匹配度: {max_val:.2f}")
            return True
        time.sleep(0.5)
    print("[支付方式 TIMEOUT] 未检测到 支付方式")
    return False

def click_fat_method(timeout=8):
    """检测并点击 fat method,失败 False"""
    start = time.time()
    while time.time() - start < timeout:
        screenshot = safe_screenshot()
        screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
        path = "fatmethod.png"
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[支付方式2 WARN] 模板不存在: {path}")
            return False
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= 0.8:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[支付方式2 FOUND] 点击成功, 匹配度: {max_val:.2f}")
            return True
        time.sleep(0.5)
    print("[支付方式2 TIMEOUT] 未检测到 支付方式")
    return False

def click_gift_button(timeout=8):
    """检测并点击 gift button,失败 False"""
    start = time.time()
    while time.time() - start < timeout:
        screenshot = safe_screenshot()
        screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
        path = "gift.png"
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[gift btn WARN] 模板不存在: {path}")
            return False
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= 0.8:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[gift btn FOUND] 点击成功, 匹配度: {max_val:.2f}")
            return True
        time.sleep(0.5)
    print("[gift btn TIMEOUT] 未检测到 gift btn")
    return False

def input_username(username):
    """输入用户名"""
    print("[INFO] 输入文本: "+username)
    pyautogui.typewrite(username, interval=0.1)

def click_anmsly_checkbox():
    """检测并点击 anmsly checkbox,失败 False"""
    screenshot = safe_screenshot()
    screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
    path = "anonymously.png"
    template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if template is None:
        print(f"[anonymously checkbox WARN] 模板不存在: {path}")
        return False
    w, h = template.shape[::-1]
    res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)
    if max_val >= 0.8:
        cx = max_loc[0] + w // 2
        cy = max_loc[1] + h // 2
        pyautogui.moveTo(cx, cy, duration=0.2)
        pyautogui.click()
        print(f"[anonymously checkbox FOUND] 点击成功, 匹配度: {max_val:.2f}")
        return True
    print("[anonymously checkbox TIMEOUT] 未检测到 anonymously checkbox")
    return False

def click_continue_button(timeout=8):
    """检测并点击 continue button,失败 False"""
    start = time.time()
    while time.time() - start < timeout:
        screenshot = safe_screenshot()
        screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
        path = "Continue.png"
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[continue button WARN] 模板不存在: {path}")
            return False
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= 0.8:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[continue button FOUND] 点击成功, 匹配度: {max_val:.2f}")
            return True
        time.sleep(0.5)
    print("[continue button TIMEOUT] 未检测到 continue button")
    return False


def get_balance():
    """通过socket连接插件获取余额"""
    global last_sync_screenshot, last_sync_time, last_sync_balance  # 声明使用全局变量
    balance, img = get_balance_func()
    # 将PIL图像对象转换为字节流，然后进行base64编码
    import io
    buffered = io.BytesIO()
    img.save(buffered, format="JPEG")
    _img = compress_base64_image(
        base64_str=base64.b64encode(buffered.getvalue()).decode('utf-8'),
        quality=70,
        img_format="JPEG"
    )
    # last_sync_screenshot = _img
    last_sync_screenshot = ''
    last_sync_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    last_sync_balance = balance
    print("成功获取余额并且同步截图")
    return balance

# ================== 主逻辑 ==================

def sync_fats_balance_o():
    url = "https://fatality.win"

    print("[INFO] 启动 Chrome 浏览器...")
    subprocess.Popen([chrome_path,
                      f'--user-data-dir={user_data}',
                      '--profile-directory=Default',
                      '--no-first-run',
                      '--no-default-browser-check',
                      url])
    time.sleep(5)  # 等待浏览器启动

    print("[INFO] 将浏览器置于前台...")
    bring_window_to_front("Chrome")
    time.sleep(1)

    print("[INFO] 检测 CF 盾...")
    for _ in range(5):
        if check_cf():
            print("[SUCCESS] 已点击 CF 盾！")
            break
        time.sleep(0.5)
    else:
        print("[WARN] 未检测到 CF 盾")

    print("[INFO] 检测 wallet 按钮...")
    if not check_wallet(timeout=8):
        print("[EXIT] 未找到 wallet，自动退出")
        return

    print("[INFO] 点击 wallet 后等待 5 秒...")
    time.sleep(5)

    print("[STEP] 截图并 OCR 识别余额...")
    balance = get_balance()  # 现在会无限重试直到成功获取余额
    print(f"[SUCCESS] 识别到余额: {balance} fat$")
    if int(balance) >= 288:
        print("[INFO] 余额足够进行订阅的续费")
        can_buy_sub = True
    else:
        print("[INFO] 余额不足288fat，订阅商品将停止购买")
        can_buy_sub = False
    
    return {"code": 0, "fats": balance, "can_buy_sub": can_buy_sub, "can_buy_sub_count": str(int(balance) // 288), "token": "ctcake1337"} #balance除以288然后舍去小数点，得到可以购买多少个订阅

def refush_fats():
    print("[INFO] 开始刷新余额")
    pyautogui.hotkey('ctrl', 'r')
    if check_wallet():
        print("成功点击 wallet")

    time.sleep(1)
    balance = get_balance()  # 现在会无限重试直到成功获取余额
    print(f"[SUCCESS] 识别到余额: {balance} fat$")
    if int(balance) >= 288:
        print("[INFO] 余额足够进行订阅的续费")
        can_buy_sub = True
    else:
        print("[INFO] 余额不足288fat，订阅商品将停止购买")
        can_buy_sub = False
    balance_result = {"code": 0, "fats": balance, "can_buy_sub": can_buy_sub, "can_buy_sub_count": str(int(balance) // 288), "token": "ctcake1337"}
    try:
        resp = requests.post(SYNC_URL, json=balance_result, timeout=None, proxies=proxies)  # 不限制超时
        if resp.status_code == 200:
            print("[SYNC SUCCESS] 由于用户购买，数据已同步至 sync.php" + resp.text)
            print(json.dumps(resp.json()))
        else:
            print(f"[SYNC FAIL] 由于用户购买，数据同步但错误：状态码: {resp.status_code}, 内容: {resp.text}")
    except Exception as e:
        print(f"[SYNC ERROR] {e}")

    return balance_result
    



def start_buy_sub(username, order_id, order_amount):
    print("[INFO] 开始购买订阅")
    url = "https://fatality.win"

    print("[INFO] 启动 Chrome 浏览器...")
    subprocess.Popen([chrome_path,
                      f'--user-data-dir={user_data}',
                      '--profile-directory=Default',
                      '--no-first-run',
                      '--no-default-browser-check',
                      '--disable-popup-blocking',
                      url])
    time.sleep(5)  # 等待浏览器启动

    print("[INFO] 将浏览器置于前台...")
    bring_window_to_front("fatality.win")
    time.sleep(1)

    print("[INFO] 检测 CF 盾...")
    for _ in range(5):
        if check_cf():
            print("[SUCCESS] 已点击 CF 盾！")
            break
        time.sleep(0.5)
    else:
        print("[WARN] 未检测到 CF 盾")
        if check_store():
            print("[SUCCESS] Store已点击，等待3秒后PageDown然后开始购买")
            time.sleep(3)

            pyautogui.press('end')
            #按下pagedown键
            pyautogui.press('pagedown')
            time.sleep(1)
            click_pay_method()
            time.sleep(1)
            click_fat_method()
            time.sleep(1)
            click_gift_button()
            time.sleep(1)
            input_username(username)
            time.sleep(2)
            print("输入完成，按下TAB")
            pyautogui.press('tab')
            time.sleep(1)
            click_anmsly_checkbox()
            time.sleep(1)
            click_continue_button()
            time.sleep(5)
            #截图当前页面并且转为base64
            # 截图当前页面
            img = safe_screenshot()
            filename = "temp_"+datetime.now().strftime("%Y%m%d%H%M%S")+".png"
            img.save(filename)

            # 调用处理函数
            b64_img, final_filename = process_screenshot(filename, sensitive_keywords=["CTCAKE"], watermark="为FA用户 "+username + " 购买\n商品:FATALITY订阅-1月\n当前时间:"+datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            os.remove(filename)

            if final_filename is not None:
                os.rename(final_filename, filename)
                print(f"[INFO] 删除临时文件: {filename}")
            #检查是否有报错信息
            status, alert_or_error = get_alert_func()
            if status == "success":
                print("[ALERT] 获取到ALERT，购买失败"+alert_or_error)
                refund_bool,refund_msg = refund(order_id, float(order_amount))
                return {"code": -1, "msg": "购买时出现错误:"+alert_or_error+"。正在为您原路退款。\n退款结果:"+str(refund_bool)+"退款信息:"+refund_msg, "screenshot": b64_img}
            else:
                print("[SUCCESS] 没有ALERT，购买成功")
            refush_fats()
            return {"code": 0, "msg": "购买成功。结果请查看下方图片。", "screenshot": b64_img}
            
        
        else:
            print("[FAIL] 未能识别到商店，退出")
            refund_bool,refund_msg = refund(order_id, float(order_amount))
            return {"code": 1,"msg": "出现未知错误，即将为您原路退款，请注意查收。\n退款结果:"+str(refund_bool)+"退款信息:"+refund_msg}

def click_send_potins(timeout=8):
    print("[sendpoints INFO] 点击 send points")
    """检测并点击 send points,失败 False"""
    start = time.time()
    while time.time() - start < timeout:
        screenshot = safe_screenshot()
        screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
        path = "sendpoints.png"
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[sendpoints WARN] 模板不存在: {path}")
            return False
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= 0.8:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[sendpoints FOUND] 点击成功, 匹配度: {max_val:.2f}")
            return True
        time.sleep(0.5)
    print("[sendpoints TIMEOUT] 未检测到 sendpoints")
    return False

def click_user_pay_fee(timeout=8):
    print("[click_user_pay_fee INFO] 点击 send points")
    """检测并点击 user_pay_fee,失败 False"""
    start = time.time()
    while time.time() - start < timeout:
        screenshot = safe_screenshot()
        screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
        path = "ufee.png"
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[click_user_pay_fee WARN] 模板不存在: {path}")
            return False
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= 0.8:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[click_user_pay_fee FOUND] 点击成功, 匹配度: {max_val:.2f}")
            return True
        time.sleep(0.5)
    print("[click_user_pay_fee TIMEOUT] 未检测到 click_user_pay_fee")
    return False


def click_send(timeout=8):
    print("[click_send INFO] 点击 send points")
    """检测并点击 click_send,失败 False"""
    start = time.time()
    while time.time() - start < timeout:
        screenshot = safe_screenshot()
        screenshot_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
        path = "send.png"
        template = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"[click_send WARN] 模板不存在: {path}")
            return False
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(screenshot_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val >= 0.8:
            cx = max_loc[0] + w // 2
            cy = max_loc[1] + h // 2
            pyautogui.moveTo(cx, cy, duration=0.2)
            pyautogui.click()
            print(f"[click_send FOUND] 点击成功, 匹配度: {max_val:.2f}")
            return True
        time.sleep(0.5)
    print("[click_send TIMEOUT] 未检测到 click_send")
    return False



def buy_fat(username, amount, order_id, order_amount):
    amount = str(amount)
    print("[INFO] 开始购买FATs")
    url = "https://fatality.win"

    print("[INFO] 启动 Chrome 浏览器...")
    subprocess.Popen([chrome_path,
                      f'--user-data-dir={user_data}',
                      '--profile-directory=Default',
                      '--no-first-run',
                      '--no-default-browser-check',
                      '--disable-popup-blocking',
                      '--disable-blink-features=AutomationControlled',
                      url])
    time.sleep(5)  # 等待浏览器启动

    print("[INFO] 将浏览器置于前台...")
    bring_window_to_front("fatality.win")
    time.sleep(1)

    print("[INFO] 检测 CF 盾...")
    for _ in range(5):
        if check_cf():
            print("[SUCCESS] 已点击 CF 盾！")
            break
        time.sleep(0.5)
    else:
        print("[WARN] 未检测到 CF 盾")

    print("[INFO] 检测 wallet 按钮...")
    if not check_wallet(timeout=8):
        print("[EXIT] 未找到 wallet，自动退出")
        return

    print("[INFO] 点击 wallet 后等待 5 秒...")
    time.sleep(5)

    print("[STEP] 截图并 OCR 识别余额...")
    balance = get_balance()  # 现在会无限重试直到成功获取余额
    print(f"[SUCCESS] 识别到余额: {balance} fat$")
    # 如果是整数
    if balance.isdigit():
        if check_wallet():
            print("[SUCCESS] 成功点击wallet")
            # #按下键盘End键
            # pyautogui.press('end')
            time.sleep(1)
            click_send_potins()
            time.sleep(1)
            input_username(username)
            time.sleep(1)
            print("完成，TAB")
            #按下tab键
            pyautogui.press('tab')
            time.sleep(1)
            print("输入金额："+str(amount))
            input_username(amount)
            time.sleep(1)
            pyautogui.press('tab')
            click_user_pay_fee()
            time.sleep(1)
            click_send()
            time.sleep(2)
            img = safe_screenshot()
            filename = "temp_"+datetime.now().strftime("%Y%m%d%H%M%S")+".png"
            img.save(filename)

            # 调用处理函数
            b64_img, final_filename = process_screenshot(filename, sensitive_keywords=["CAKE"], watermark="为FA用户 "+username + " 购买\n商品:Workshop代币FAT$ "+str(amount)+" 个\n当前时间:"+datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            if final_filename is not None:
                os.remove(filename)
                print("[INFO] 删除临时截图文件")
            #检查是否有报错信息
            status, alert_or_error = get_alert_func()
            if status == "success":
                print("[ALERT] 获取到ALERT，购买失败"+alert_or_error)
                refund_bool,refund_msg = refund(order_id, float(order_amount))
                return {"code": -1, "msg": "购买时出现错误:"+alert_or_error+"。正在为您原路退款。\n退款结果:"+str(refund_bool)+"退款信息:"+refund_msg, "screenshot": b64_img}
            else:
                print("[SUCCESS] 没有ALERT，购买成功")
            refush_fats()
            return {"code": 0, "msg": "购买成功。结果请查看下方图片。", "screenshot": b64_img}
            
        else:
            print("[FAIL] 未能识别到商店，退出")
            return {"code": 1,"msg": "出现未知错误，我们即将为您原路退款，请注意查收。"}
    else:
        print("[FAIL] 结果不是整数，错误")
        refund_bool,refund_msg = refund(order_id, float(order_amount))
        return {"code": 1,"msg": "出现未知错误，即将为您原路退款，请注意查收。\n退款结果:"+str(refund_bool)+"退款信息:"+refund_msg}
        
