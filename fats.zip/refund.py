from get_epay_sign import refund_order
PID = 1001 
KEY = ""

def refund(order_id, amount):
    
    result = refund_order(
        pid=PID,
        key=KEY,
        out_trade_no=order_id,
        money=amount
    )
    if result['code'] != 0:
        print(f"退款失败: {result['msg']}")
        return False, result['msg']
    else:
        print(f"退款成功: {result['msg']}")
        return True, '手续费￥1。' + result['msg']

if __name__ == '__main__':
    # 退款金额
    refund_amount = 0.01
    # 订单号
    order_no = '2025121314440335579'
    # 退款原因
    refund_reason = '测试退款'
    # 退款订单号
    refund(order_no, refund_amount)