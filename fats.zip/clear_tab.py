import asyncio
import websockets
import threading
import time
import queue
import pyautogui
clients = set()
loop = None  # 全局事件循环
message_queue = []  # 缓存未发送消息
balance_responses = {}  # 存储余额响应
alert_responses = {}  # 存储alert响应


# ================= WebSocket Handler =================
async def handler(ws):
    clients.add(ws)
    print("[WS] Extension connected")

    # 发送缓存消息
    while message_queue:
        msg = message_queue.pop(0)
        try:
            await ws.send(msg)
        except Exception as e:
            print("[WS] Failed to send cached message:", e)

    try:
        async for msg in ws:
            # print("[WS] Received from extension:", msg)
            # 处理余额响应
            if msg.startswith("balance:"):
                balance = msg.split(":", 1)[1]
                print("[WS] Received balance:", balance)
                # 将余额放入响应队列，只处理一个请求
                if balance_responses:
                    q_id, q = next(iter(balance_responses.items()))
                    q.put(("success", balance))
                    # 移除已使用的队列
                    del balance_responses[q_id]
            elif msg.startswith("balance_error:"):
                error = msg.split(":", 1)[1]
                print("[WS] Received balance error:", error)
                # 将错误信息放入响应队列，只处理一个请求
                if balance_responses:
                    q_id, q = next(iter(balance_responses.items()))
                    q.put(("error", error))
                    # 移除已使用的队列
                    del balance_responses[q_id]
            # 处理alert响应
            elif msg.startswith("alert:"):
                alert = msg.split(":", 1)[1]
                print("[WS] Received alert:", alert)
                # 将alert放入响应队列，只处理一个请求
                if alert_responses:
                    q_id, q = next(iter(alert_responses.items()))
                    q.put(("success", alert))
                    # 移除已使用的队列
                    del alert_responses[q_id]
            elif msg.startswith("alert_error:"):
                error = msg.split(":", 1)[1]
                print("[WS] Received alert error:", error)
                # 将错误信息放入响应队列，只处理一个请求
                if alert_responses:
                    q_id, q = next(iter(alert_responses.items()))
                    q.put(("error", error))
                    # 移除已使用的队列
                    del alert_responses[q_id]
    except Exception as e:
        print("[WS] Exception in handler:", e)
    finally:
        clients.remove(ws)
        print("[WS] Extension disconnected")


# ================= 广播消息 =================
async def _broadcast(msg: str):
    if not clients:
        message_queue.append(msg)
        print("[WS] No connected clients, message queued:", msg)
        return

    clients_copy = list(clients)
    for ws in clients_copy:
        try:
            await ws.send(msg)
        except websockets.ConnectionClosed:
            print("[WS] Client disconnected, removing")
            clients.remove(ws)
        except Exception as e:
            print("[WS] Failed to send message:", e)
            clients.remove(ws)

# ================= 线程安全发送接口 =================
def send_to_extension(msg: str):
    """
    可以在任意线程调用，向扩展发送消息
    """
    global loop
    if loop is None:
        print("[WS] ERROR: WS loop not started yet")
        message_queue.append(msg)
        return

    # 调度协程到事件循环线程执行
    future = asyncio.run_coroutine_threadsafe(_broadcast(msg), loop)
    try:
        future.result(timeout=1)  # 等待协程完成，保证消息发送
    except Exception as e:
        print("[WS] Failed to send '{}': {}".format(msg, e))


# ================= 心跳线程 =================
def heartbeat():
    while True:
        time.sleep(10)
        send_to_extension("heartbeat")


# ================= 启动 WS 服务器 =================
def start_server(host="127.0.0.1", port=8765):
    global loop
    loop = asyncio.new_event_loop()

    async def run():
        async with websockets.serve(handler, host, port, ping_interval=5, ping_timeout=20):
            print(f"[WS] Server started on ws://{host}:{port}")
            await asyncio.Future()  # 永远阻塞

    def thread_target():
        asyncio.set_event_loop(loop)
        loop.run_until_complete(run())

    threading.Thread(target=thread_target, daemon=True).start()
    print("[WS] Server thread started")

    threading.Thread(target=heartbeat, daemon=True).start()
    print("[WS] Heartbeat thread started")


# ================= 清理 Tab =================
def clear_tab_func():
    """
    可以在任意线程调用，向扩展发送 'clean_tabs' 指令
    """
    send_to_extension("clean_tabs")
    print("[WS] Sent 'clean_tabs' to extension")

def get_balance_func(timeout=30):
    """
    可以在任意线程调用，向扩展发送 'get_balance' 指令,然后获取回复

    Args:
        timeout: 等待响应的超时时间(秒)，默认30秒

    Returns:
        tuple: (status, balance_or_error)
            status: "success" 表示成功获取余额，"error" 表示获取失败
            balance_or_error: 成功时为余额值，失败时为错误信息
    """
    # 创建一个唯一的队列ID
    import uuid
    q_id = str(uuid.uuid4())
    response_queue = queue.Queue()

    # 将响应队列存储起来
    balance_responses[q_id] = response_queue

    # 发送获取余额请求
    send_to_extension("get_balance")
    print("[WS] Sent 'get_balance' to extension")

    try:
        # 等待响应
        status, result = response_queue.get(timeout=timeout)
        #截图屏幕
        screen = pyautogui.screenshot()
        return result,screen
    except queue.Empty:
        # 超时处理
        print(f"[WS] Timeout waiting for balance response after {timeout} seconds")
        # 清理队列
        if q_id in balance_responses:
            del balance_responses[q_id]
        return ("error", f"Timeout after {timeout} seconds")
    except Exception as e:
        # 其他错误处理
        print(f"[WS] Error while waiting for balance response: {e}")
        # 清理队列
        if q_id in balance_responses:
            del balance_responses[q_id]

def get_alert_func(timeout=30):
    """
    可以在任意线程调用，向扩展发送 'get_alert' 指令,然后获取回复

    Args:
        timeout: 等待响应的超时时间(秒)，默认30秒

    Returns:
        tuple: (status, alert_or_error)
            status: "success" 表示成功获取alert，"error" 表示获取失败
            alert_or_error: 成功时为alert内容，失败时为错误信息
    """
    # 创建一个唯一的队列ID
    import uuid
    q_id = str(uuid.uuid4())
    response_queue = queue.Queue()

    # 将响应队列存储起来
    alert_responses[q_id] = response_queue

    # 发送获取alert请求
    send_to_extension("get_alert")
    print("[WS] Sent 'get_alert' to extension")

    try:
        # 等待响应
        status, result = response_queue.get(timeout=timeout)
        return status, result
    except queue.Empty:
        # 超时处理
        print(f"[WS] Timeout waiting for alert response after {timeout} seconds")
        # 清理队列
        if q_id in alert_responses:
            del alert_responses[q_id]
        return ("error", f"Timeout after {timeout} seconds")
    except Exception as e:
        # 其他错误处理
        print(f"[WS] Error while waiting for alert response: {e}")
        # 清理队列
        if q_id in alert_responses:
            del alert_responses[q_id]
        return ("error", str(e))