import hashlib
import requests
from typing import Dict, Optional


def get_sign(params: dict, key: str) -> str:
    # 排序（按 key 升序）
    items = sorted(params.items(), key=lambda x: x[0])

    sign_str = ""

    for k, v in items:
        if k not in ("sign", "sign_type") and v != "":
            sign_str += f"{k}={v}&"

    # 去掉最后一个 &
    if sign_str.endswith("&"):
        sign_str = sign_str[:-1]

    # 拼接 key
    sign_str += key

    # md5
    return hashlib.md5(sign_str.encode("utf-8")).hexdigest()

def refund_order(
    pid: int,
    key: str,
    out_trade_no: str,
    money: str,
    api_url: str = "https://xxxx.com/api.php?act=refund"
) -> Dict:
    """
    发起订单退款请求
    
    Args:
        pid: 商户ID
        key: 商户密钥
        out_trade_no: 自行判断订单号类型
        money: 退款金额
        trade_no: 可选，易支付订单号
        api_url: API地址，默认为官方地址
    
    Returns:
        Dict: API响应结果
    """
    # 构建请求参数
    params = {
        'pid': str(pid),
        'key': key,
        'money': money
    }
    
    # # 如果提供了trade_no，则使用它
    # if trade_no:
    #     params['trade_no'] = trade_no
    if 'HVH' in out_trade_no or 'ORDER' in out_trade_no:
        #使用out_trade_no作为退款订单号
        params['out_trade_no'] = out_trade_no
    else:
        #使用trade_no作为退款订单号
        params['trade_no'] = out_trade_no
    # 生成签名
    sign = get_sign(params, key)
    params['sign'] = sign
    
    try:
        # 发送POST请求
        response = requests.post(api_url, data=params)
        return response.json()
    except requests.RequestException as e:
        return {
            'code': -1,
            'msg': f'请求失败: {str(e)}'
        }
