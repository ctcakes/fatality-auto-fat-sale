// =====================
// background.js
// =====================

let ws = null;
let wsStatus = "disconnected";
function sendHeartbeat() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send("pong"); // 可自定义
    }
    setTimeout(sendHeartbeat, 5000); // 5 秒一次
}
// ================= WS 连接逻辑 =================
function connectWS() {
    try {
        // 避免重复连接
        if (ws && ws.readyState === WebSocket.OPEN) return;

        ws = new WebSocket("ws://127.0.0.1:8765");

        ws.onopen = () => {
            wsStatus = "connected";
            broadcastStatus();
            console.log("[WS] Connected to Python server");
        };

        ws.onmessage = (event) => {
            const msg = event.data;
            if (msg === "heartbeat") {
                console.log("[WS] Heartbeat received");
                return;
            }

            if (msg === "clean_tabs") {
                chrome.tabs.query({}, (tabs) => {
                    if (tabs.length <= 1) return;
                    const keep = tabs[0].id;
                    for (const t of tabs) {
                        if (t.id !== keep) chrome.tabs.remove(t.id);
                    }
                });
                console.log("[WS] clean_tabs executed");
            }

            if (msg === "get_balance") {
                getBalance(true); // 传入true表示需要通过WebSocket回复余额
                console.log("[WS] get_balance executed");
            }

            if (msg === "get_alert") {
                getAlert(true); // 传入true表示需要通过WebSocket回复alert内容
                console.log("[WS] get_alert executed");
            }
        };

        ws.onclose = () => {
            wsStatus = "disconnected";
            broadcastStatus();
            console.log("[WS] Connection closed, retrying in 1s");
            setTimeout(connectWS, 1000); // 自动重连
        };

        ws.onerror = (err) => {
            console.log("[WS] Connection error, closing socket:", err.message);
            ws.close();
        };

        ws.onopen = () => {
            console.log("[WS] Connected");
            sendHeartbeat();
        };

    } catch (e) {
        console.log("[WS] Exception in connectWS:", e);
        setTimeout(connectWS, 1000);
    }
}

function checkAndRemove() {
    // 查找所有钱包页面标签
    chrome.tabs.query({}, (tabs) => {
        for (const tab of tabs) {
            // 检查是否是钱包页面
            if (tab.url && (
                tab.url.includes("https://fatality.win") ||
                tab.url.includes("https://fatality.win/wallet")
            )) {
                // 在该标签页中执行脚本删除元素
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: () => {
                        // 查找当前页面是否存在role="alertdialog"的元素中的blockMessage
                        const alertDialogDiv = document.querySelector('div[role="alertdialog"]');
                        if (alertDialogDiv) {
                            const blockMessageDiv = alertDialogDiv.querySelector('.overlay-content .blockMessage');
                            if (blockMessageDiv) {
                                let blockMessageContent = blockMessageDiv.textContent.trim();
                                const pluginAlertTextDOM = document.querySelector('p.alert');
                                pluginAlertTextDOM.textContent = blockMessageContent;
                            }
                        }




                        // 删除dataList元素
                        const dataListEl = document.querySelector("div.dataList");
                        if (dataListEl) {
                            dataListEl.remove();
                            console.log("[Wallet] dataList removed");
                        }

                        // 修改p-navgroup-linkText内容
                        const navGroupLinkText = document.querySelector("span.p-navgroup-linkText");
                        if (navGroupLinkText) {
                            navGroupLinkText.textContent = "续费卡网hvhgod.onl";
                            console.log("[Wallet] Modified p-navgroup-linkText");
                        }

                        // 删除avatar元素
                        const avatarEl = document.querySelector("span.avatar.avatar--xxs");
                        if (avatarEl) {
                            avatarEl.remove();
                            console.log("[Wallet] Removed avatar element");
                        }

                        // 修改FATALITY为CTCAKE
                        const ftTextEl = document.querySelector('a.ft-text[href="/"]');
                        if (ftTextEl && ftTextEl.textContent === "FATALITY") {
                            ftTextEl.textContent = "续费/FAT$购买卡网hvhgod.onl";
                        }

                        const notice = document.querySelector('div.notice-content');
                        if (notice) {
                            notice.innerHTML = 'FA续费卡网/FAT$购买卡网hvhgod.onl<br>' + new Date().toLocaleString();
                        }

                        //修改<h1 class="p-title-value">Wallet</h1>内容
                        const walletTitle = document.querySelector('h1.p-title-value');
                        if (walletTitle) {
                            walletTitle.textContent = "卡网全自动发货，放心购买";
                            console.log("[Wallet] Modified h1.p-title-value");
                        }


                        //删除抽奖入口
                        const advent = document.querySelector("#advent-present");
                        if (advent) {
                            advent.remove();
                            console.log("[Wallet] Removed advent-present element");
                        }

                        // 删除导航列表中的特定li元素
                        const navListEl = document.querySelector("ul.p-nav-list.js-offCanvasNavSource");
                        if (navListEl) {
                            // 查找并删除Forums菜单
                            const forumsLinks = navListEl.querySelectorAll('a.p-navEl-link[data-nav-id="forums"]');
                            forumsLinks.forEach(link => {
                                const li = link.closest('li');
                                if (li) {
                                    li.remove();
                                    console.log("[Wallet] Removed Forums menu");
                                }
                            });

                            // 查找并删除Members菜单
                            const membersLinks = navListEl.querySelectorAll('a.p-navEl-link[data-nav-id="members"]');
                            membersLinks.forEach(link => {
                                const li = link.closest('li');
                                if (li) {
                                    li.remove();
                                    console.log("[Wallet] Removed Members menu");
                                }
                            });

                            // 查找并删除Discord菜单
                            const discordLinks = navListEl.querySelectorAll('a.p-navEl-link[data-nav-id="discord"]');
                            discordLinks.forEach(link => {
                                const li = link.closest('li');
                                if (li) {
                                    li.remove();
                                    console.log("[Wallet] Removed Discord menu");
                                }
                            });

                            // 查找并删除Workshop菜单
                            const workshopLinks = navListEl.querySelectorAll('a.p-navEl-link[data-nav-id="ws2"]');
                            workshopLinks.forEach(link => {
                                const li = link.closest('li');
                                if (li) {
                                    li.remove();
                                    console.log("[Wallet] Removed Workshop menu");
                                }
                            });

                            // 查找并删除Roulette菜单
                            const rouletteLinks = navListEl.querySelectorAll('a.p-navEl-link[data-nav-id="rrRoulette"]');
                            rouletteLinks.forEach(link => {
                                const li = link.closest('li');
                                if (li) {
                                    li.remove();
                                    console.log("[Wallet] Removed Roulette menu");
                                }
                            });

                            // 查找并删除CS2 Tickets菜单
                            const cs2TicketsLinks = navListEl.querySelectorAll('a.p-navEl-link[data-nav-id="nfTickets"]');
                            cs2TicketsLinks.forEach(link => {
                                const li = link.closest('li');
                                if (li) {
                                    li.remove();
                                    console.log("[Wallet] Removed CS2 Tickets menu");
                                }
                            });

                            // 查找并删除CSGO Tickets菜单
                            const csgoTicketsLinks = navListEl.querySelectorAll('a.p-navEl-link[data-nav-id="mjstSupportTicket"]');
                            csgoTicketsLinks.forEach(link => {
                                const li = link.closest('li');
                                if (li) {
                                    li.remove();
                                    console.log("[Wallet] Removed CSGO Tickets menu");
                                }
                            });



                        }

                        return true;
                    }
                }, (results) => {
                    if (chrome.runtime.lastError) {
                        console.error("[Wallet] Error executing script:", chrome.runtime.lastError);
                        return;
                    }

                    if (results && results[0] && results[0].result) {
                        console.log("[Wallet] Successfully modified page elements from tab:", tab.id);
                    }
                });
            }
        }
    });
}

// ================= 获取余额功能 =================
function getBalance(replyViaWS = false) {
    // 获取当前活动标签页
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length === 0) {
            // 没有活动标签页，创建新的钱包标签页
            createWalletTabAndFetchBalance(replyViaWS);
            return;
        }

        const activeTab = tabs[0];

        // 检查当前活动标签页是否是钱包页面
        if (activeTab.url && (
            activeTab.url.includes("https://fatality.win/wallet/wallet") ||
            activeTab.url.includes("https://fatality.win/wallet")
        )) {
            // 当前活动标签页是钱包页面，直接获取余额
            fetchBalanceFromTab(activeTab.id, replyViaWS);
        } else {
            // 当前活动标签页不是钱包页面，创建新的钱包标签页
            createWalletTabAndFetchBalance(replyViaWS);
        }
    });
}

// 从指定标签页获取余额
function getAlert(replyViaWS = false) {
    // 获取当前活动标签页
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length === 0) {
            const errorMsg = "Error: No active tab found";
            console.log("[Alert] Could not retrieve alert: No active tab");
            chrome.runtime.sendMessage({ alert: errorMsg }).catch(() => { });
            if (replyViaWS && ws && ws.readyState === WebSocket.OPEN) {
                ws.send("alert_error:" + errorMsg);
            }
            return;
        }

        const activeTab = tabs[0];
        let attempts = 0;
        const maxAttempts = 5;

        // 定义获取alert的函数，支持重试
        const fetchAlertWithRetry = () => {
            attempts++;
            console.log(`[Alert] Attempt ${attempts}/${maxAttempts}`);

            // 执行脚本获取alert内容
            chrome.scripting.executeScript({
                target: { tabId: activeTab.id },
                func: () => {
                    // 查找当前页面是否存在role="alertdialog"的元素中的blockMessage
                    const alertDialogDiv = document.querySelector('div[role="alertdialog"]');
                    if (alertDialogDiv) {
                        const blockMessageDiv = alertDialogDiv.querySelector('.overlay-content .blockMessage');
                        if (blockMessageDiv) {
                            const blockMessageContent = blockMessageDiv.textContent.trim();
                            return blockMessageContent;
                        } else {
                            return null;
                        }
                    } else {
                        return null;
                    }
                }
            }, (results) => {
                if (chrome.runtime.lastError) {
                    console.error("Error executing script:", chrome.runtime.lastError);
                    const errorMsg = "Error: " + chrome.runtime.lastError.message;
                    chrome.runtime.sendMessage({ alert: errorMsg }).catch(() => { });
                    if (replyViaWS && ws && ws.readyState === WebSocket.OPEN) {
                        ws.send("alert_error:" + errorMsg);
                    }
                    return;
                }

                if (results && results[0] && results[0].result) {
                    const alertContent = results[0].result;
                    console.log("[Alert] Retrieved:", alertContent);
                    // 发送alert内容到popup
                    chrome.runtime.sendMessage({ alert: alertContent }).catch(() => { });
                    // 如果是通过WebSocket请求的，则通过WebSocket回复alert内容
                    if (replyViaWS && ws && ws.readyState === WebSocket.OPEN) {
                        ws.send("alert:" + alertContent);
                    }
                } else if (attempts < maxAttempts) {
                    // 如果未找到且还有尝试次数，1秒后重试
                    setTimeout(fetchAlertWithRetry, 1000);
                } else {
                    // 所有尝试都失败
                    const errorMsg = "Error: Alert not found after " + maxAttempts + " attempts";
                    console.log("[Alert] Could not retrieve alert after " + maxAttempts + " attempts");
                    chrome.runtime.sendMessage({ alert: errorMsg }).catch(() => { });
                    if (replyViaWS && ws && ws.readyState === WebSocket.OPEN) {
                        ws.send("alert_error:" + errorMsg);
                    }
                }
            });
        };

        // 开始获取alert
        fetchAlertWithRetry();
    });
}

function fetchBalanceFromTab(tabId, replyViaWS) {
    // 执行脚本获取余额
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: () => {
            const balanceElement = document.querySelector('span.wallet-balance.positive');
            if (balanceElement) {
                // 提取纯数字，删除所有非数字字符
                const text = balanceElement.textContent;
                const number = text.replace(/\D/g, '');
                return number;
            }
            return null;
        }
    }, (results) => {
        if (chrome.runtime.lastError) {
            console.error("Error executing script:", chrome.runtime.lastError);
            const errorMsg = "Error: " + chrome.runtime.lastError.message;
            chrome.runtime.sendMessage({ balance: errorMsg }).catch(() => { });
            if (replyViaWS && ws && ws.readyState === WebSocket.OPEN) {
                ws.send("balance_error:" + errorMsg);
            }
            return;
        }

        if (results && results[0] && results[0].result) {
            const balance = results[0].result;
            console.log("[Balance] Retrieved:", balance);
            // 发送余额到popup
            chrome.runtime.sendMessage({ balance: balance }).catch(() => { });
            // 如果是通过WebSocket请求的，则通过WebSocket回复余额
            if (replyViaWS && ws && ws.readyState === WebSocket.OPEN) {
                ws.send("balance:" + balance);
            }
        } else {
            const errorMsg = "Error: Balance not found";
            console.log("[Balance] Could not retrieve balance");
            chrome.runtime.sendMessage({ balance: errorMsg }).catch(() => { });
            if (replyViaWS && ws && ws.readyState === WebSocket.OPEN) {
                ws.send("balance_error:" + errorMsg);
            }
        }
    });
}

// 创建新的钱包标签页并获取余额
function createWalletTabAndFetchBalance(replyViaWS) {
    chrome.tabs.create({ url: "https://fatality.win/wallet/wallet" }, (tab) => {
        // 等待页面加载完成后获取余额
        const listener = (tabId, changeInfo, tab) => {
            if (tabId === tab.id && changeInfo.status === 'complete') {
                // 移除监听器
                chrome.tabs.onUpdated.removeListener(listener);

                // 执行脚本获取余额
                setTimeout(() => {
                    fetchBalanceFromTab(tab.id, replyViaWS);
                }, 2000); // 给页面2秒加载时间
            }
        };

        // 添加监听器
        chrome.tabs.onUpdated.addListener(listener);
    });
}

// ================= 广播状态给 popup =================
function broadcastStatus() {
    chrome.runtime.sendMessage({ ws_status: wsStatus }).catch(() => { });
}

// ================= 手动重连 =================
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg === "manual_reconnect") {
        if (ws) ws.close(); // 会触发自动重连
        sendResponse({ ok: true });
        return true;
    }

    if (msg.ask_status) {
        sendResponse({ ws_status: wsStatus });
        return true;
    }

    if (msg.get_balance) {
        // 根据reply_via_ws参数决定是否通过WebSocket回复余额
        const replyViaWS = msg.reply_via_ws !== undefined ? msg.reply_via_ws : true;
        getBalance(replyViaWS);
        sendResponse({ ok: true });
        return true;
    }
});

// ================= 启动 =================
connectWS();
setInterval(checkAndRemove, 500);
