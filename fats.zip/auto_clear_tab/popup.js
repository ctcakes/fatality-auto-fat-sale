const statusEl = document.getElementById("status");
const btn = document.getElementById("reconnect");
const logEl = document.getElementById("log");

function log(msg) {
    const time = new Date().toLocaleTimeString();
    logEl.innerHTML += `[${time}] ${msg}<br>`;
    logEl.scrollTop = logEl.scrollHeight;
}

function updateStatus(s) {
    statusEl.textContent = "Status: " + s;
    statusEl.className = s; // connected / disconnected
}

// 获取当前 WS 状态
chrome.runtime.sendMessage({ ask_status: true }, (response) => {
    if (chrome.runtime.lastError) {
        updateStatus("disconnected");
        log("Cannot get status (runtime error)");
        return;
    }
    if (response && response.ws_status) {
        updateStatus(response.ws_status);
        log("Current status: " + response.ws_status);
    } else {
        updateStatus("disconnected");
        log("No status response");
    }
});

// 监听 background 广播
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.ws_status) {
        updateStatus(msg.ws_status);
        log("Status updated: " + msg.ws_status);
    }
});

// 手动重连
btn.addEventListener("click", () => {
    chrome.runtime.sendMessage("manual_reconnect", (response) => {
        if (chrome.runtime.lastError) {
            log("Manual reconnect failed");
            return;
        }
        log("Manual reconnect triggered");
    });
});

// 获取余额
const getBalanceBtn = document.getElementById("getBalance");
const balanceEl = document.getElementById("balance");

getBalanceBtn.addEventListener("click", () => {
    log("Requesting balance...");
    chrome.runtime.sendMessage({ get_balance: true, reply_via_ws: false }, (response) => {
        if (chrome.runtime.lastError) {
            log("Failed to request balance");
            return;
        }
        log("Balance request sent");
    });
});

// 获取alert
const getAlertBtn = document.getElementById("getAlert");
const alertEl = document.getElementById("alert");

getAlertBtn.addEventListener("click", () => {
    log("Requesting alert...");
    chrome.runtime.sendMessage({ get_alert: true, reply_via_ws: false }, (response) => {
        if (chrome.runtime.lastError) {
            log("Failed to request alert");
            return;
        }
        log("Alert request sent");
    });
});

// 监听余额和alert更新
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.balance) {
        balanceEl.textContent = "Balance: " + msg.balance;
        log("Balance updated: " + msg.balance);
    }
    
    if (msg.alert) {
        alertEl.textContent = "Alert: " + msg.alert;
        log("Alert updated: " + msg.alert);
    }
});
